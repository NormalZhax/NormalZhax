
ZHAX STORE PREMIUM

FITUR:
- Login/Register
- Dashboard Admin
- Riwayat Transaksi
- Dark Mode
- Search & Filter
- Checkout API
- Payment Placeholder (QRIS/Dana/OVO/GoPay)
- Responsive UI
- Modern Animation
- WhatsApp Integration
- Backend Express + MongoDB

JALANKAN BACKEND:
npm install
npm start

BUKA FRONTEND:
frontend/pages/index.html
