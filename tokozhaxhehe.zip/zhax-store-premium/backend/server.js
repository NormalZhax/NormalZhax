
const express = require('express');
const cors = require('cors');
const mongoose = require('mongoose');
const authRoutes = require('./routes/auth');
const orderRoutes = require('./routes/orders');

const app = express();

app.use(cors());
app.use(express.json());

mongoose.connect('mongodb://127.0.0.1:27017/zhaxstore');

app.use('/api/auth', authRoutes);
app.use('/api/orders', orderRoutes);

app.listen(5000, ()=> console.log('Backend running on port 5000'));
