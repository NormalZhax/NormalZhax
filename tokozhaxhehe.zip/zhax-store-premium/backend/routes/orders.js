
const router = require('express').Router();

router.get('/',(req,res)=>{
res.json([
{game:'Mobile Legends',status:'Selesai'},
{game:'PUBG',status:'Diproses'}
]);
});

router.post('/checkout',(req,res)=>{
res.json({
message:'Checkout berhasil',
payment:'QRIS'
});
});

module.exports = router;
