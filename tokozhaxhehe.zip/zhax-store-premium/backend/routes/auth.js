
const router = require('express').Router();

router.post('/register',(req,res)=>{
res.json({message:'Register berhasil'});
});

router.post('/login',(req,res)=>{
res.json({
message:'Login berhasil',
token:'sample-jwt-token'
});
});

module.exports = router;
